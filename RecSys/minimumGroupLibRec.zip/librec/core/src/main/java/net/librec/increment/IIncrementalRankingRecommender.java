package net.librec.increment;

// put this class to the top

public interface IIncrementalRankingRecommender {

}
