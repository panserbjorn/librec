package net.librec.data.structure;

public class ContextDataEntry implements LibrecDataEntry{
    @Override
    public int number() {
        return 0;
    }
}
